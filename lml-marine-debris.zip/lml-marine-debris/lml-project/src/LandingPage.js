import React from 'react';
import '../src/App.css'

class map_page extends React.Component {
  
    render() {      
      return (
        <div className="map_page">

            <div className='header'>Header</div>

            <div className='body'>
                <div className='filters'>Filters</div>
                <div className='map'>Map</div>
            </div>
            
            <div className='footer'>Footer</div>
        </div>
      );
    }
}


export default map_page
  